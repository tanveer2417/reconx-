from flask import Flask, render_template, request, jsonify
import subprocess
import os

app = Flask(__name__)

# ------------------ ROUTES ------------------

# Home Page
@app.route('/')
def homepage():
    return render_template('homepage.html')

# Subdomain Scan Page
@app.route('/subdomain')
def subdomain():
    return render_template('subdomain.html')

# OSINT Scan Page
@app.route('/osint')
def osint():
    return render_template('osint.html')

# Hosts/DNS Page
@app.route('/hosts')
def hosts():
    return render_template('hosts.html')

# Web Tech Analysis Page
@app.route('/web')
def web():
    return render_template('web.html')

# Scan History Page
@app.route('/history')
def history():
    return render_template('history.html')

# ------------------ API: Subdomain Scanner ------------------

@app.route('/api/scan', methods=['POST'])
def api_scan():
    data = request.get_json()
    domain = data.get('domain')
    if not domain:
        return jsonify({'success': False, 'error': 'Domain is required'}), 400

    try:
        # ✅ Use absolute path to avoid "file not found" errors
        main_path = os.path.abspath("main.py")
        result = subprocess.run(
            ['python', main_path, 'subdomain', '--domain', domain],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return jsonify({
                'success': False,
                'error': result.stderr.strip() or "Unknown error occurred"
            })

        subdomains = list(set([line.strip() for line in result.stdout.split('\n') if line.strip()]))

        return jsonify({
            'success': True,
            'domain': domain,
            'subdomains': subdomains,
            'errors': []
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ------------------ API: Mock OSINT ------------------

@app.route('/api/osint', methods=['POST'])
def api_osint():
    data = request.get_json()
    domain = data.get('domain')
    return jsonify({
        'success': True,
        'osint_data': [
            {'type': 'Email Found', 'value': f'admin@{domain}'},
            {'type': 'LinkedIn', 'value': f'https://linkedin.com/company/{domain}'}
        ]
    })

# ------------------ API: Mock Web Tech ------------------

@app.route('/api/webtech', methods=['POST'])
def api_webtech():
    data = request.get_json()
    domain = data.get('domain')
    return jsonify({
        'success': True,
        'technologies': ['Nginx', 'Bootstrap', 'jQuery']
    })

# ------------------ API: Mock DNS/Hosts ------------------

@app.route('/api/hosts', methods=['POST'])
def api_hosts():
    data = request.get_json()
    domain = data.get('domain')
    return jsonify({
        'success': True,
        'dns_records': [
            {'type': 'A', 'value': '192.168.1.1'},
            {'type': 'NS', 'value': 'ns1.example.com'}
        ]
    })

# ------------------ Run Flask ------------------

if __name__ == '__main__':
    app.run(debug=True)
