from reconx import subfinder_py

def run(args):
    subfinder_py.run(args.domain)
