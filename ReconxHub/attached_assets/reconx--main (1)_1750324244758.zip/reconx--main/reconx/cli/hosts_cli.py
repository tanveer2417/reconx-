from reconx.core import hosts

def run(args):
    hosts.hosts_main(args)