from reconx.core import web_analysis

def run(args):
    web_analysis.web_analysis_main(args)